import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  Mail,
  ArrowRight,
  Eye,
  EyeOff,
  Building2,
  Sparkles,
  Users,
  CheckCircle2,
  KeyRound,
  ShieldAlert
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { ThemeToggle } from '../common/ThemeToggle';
import { User } from '../../types';

export const LoginPage: React.FC = () => {
  const { workspaceInfo, users, login } = useWorkspace();

  const [email, setEmail] = useState('saeful.rohman@asliri.id');
  const [password, setPassword] = useState('••••••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg('');

    setTimeout(() => {
      // Find matching user or fallback to first user
      const foundUser = users.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (foundUser) {
        login(foundUser);
      } else {
        setErrorMsg('Email tidak terdaftar di direktori perusahaan. Silakan pilih persona demo di bawah.');
        setIsLoading(false);
      }
    }, 400);
  };

  const handleQuickLogin = (user: User) => {
    setIsLoading(true);
    setTimeout(() => {
      login(user);
    }, 250);
  };

  return (
    <div className="relative flex min-h-screen w-full flex-col justify-center bg-slate-900 selection:bg-red-500/30 selection:text-red-200">
      {/* Background Subtle Gradient & Glow */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-40 -top-40 h-96 w-96 rounded-full bg-slate-800/40 blur-3xl" />
        <div className="absolute -right-40 -bottom-40 h-96 w-96 rounded-full bg-red-950/30 blur-3xl" />
      </div>

      {/* Top Bar: Branding & Theme Toggle */}
      <header className="absolute top-0 inset-x-0 z-10 flex items-center justify-between px-6 py-5 sm:px-10">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-slate-950 text-white ring-1 ring-slate-800 shadow-md">
            {workspaceInfo.logoUrl ? (
              <img src={workspaceInfo.logoUrl} alt="Logo" className="h-6 w-6 rounded-lg object-contain" />
            ) : (
              <Building2 className="h-5 w-5 text-red-500" />
            )}
          </div>
          <div>
            <div className="text-base font-extrabold tracking-tight text-white flex items-center gap-1.5">
              <span>{workspaceInfo.name || 'WORKSPACE'}</span>
              <span className="h-1.5 w-1.5 rounded-full bg-red-500" />
            </div>
            <p className="text-[10px] font-medium text-slate-400">
              Corporate Collaboration Hub
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <ThemeToggle />
        </div>
      </header>

      {/* Main Login Card Area */}
      <main className="relative z-10 mx-auto w-full max-w-md px-4 py-20 sm:max-w-lg">
        <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/90 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
          {/* Header text */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center gap-1.5 rounded-full border border-slate-800 bg-slate-800/80 px-3 py-1 text-[11px] font-semibold text-slate-300 mb-3">
              <ShieldCheck className="h-3.5 w-3.5 text-red-500" />
              <span>Portal Akses Internal Terproteksi</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              Masuk ke Workspace
            </h1>
            <p className="mt-1.5 text-xs text-slate-400">
              Gunakan email korporat Anda (@{workspaceInfo.orgDomain || 'asliri.id'}) untuk mengakses sistem.
            </p>
          </div>

          {errorMsg && (
            <div className="mb-4 flex items-center gap-2 rounded-2xl border border-red-900/50 bg-red-950/60 p-3 text-xs text-red-300">
              <ShieldAlert className="h-4 w-4 shrink-0 text-red-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Email Perusahaan
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3 h-4 w-4 text-slate-500" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="nama@asliri.id"
                  className="w-full rounded-2xl border border-slate-700 bg-slate-800/90 pl-10 pr-4 py-2.5 text-xs font-medium text-white placeholder-slate-500 focus:border-red-500 focus:bg-slate-800 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-300">
                  Kata Sandi
                </label>
                <button
                  type="button"
                  onClick={() => alert('Fitur reset password korporat telah dikirimkan ke administrator IT perusahaan.')}
                  className="text-[11px] text-red-400 hover:text-red-300 hover:underline"
                >
                  Lupa kata sandi?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3 h-4 w-4 text-slate-500" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full rounded-2xl border border-slate-700 bg-slate-800/90 pl-10 pr-10 py-2.5 text-xs font-medium text-white placeholder-slate-500 focus:border-red-500 focus:bg-slate-800 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3 text-slate-500 hover:text-slate-300"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-400">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={e => setRememberMe(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-red-600 focus:ring-0"
                />
                <span>Ingat sesi masuk di perangkat ini</span>
              </label>
            </div>

            {/* Submit Button (Navy Primary with Crimson Touch) */}
            <button
              type="submit"
              disabled={isLoading}
              className="mt-2 flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-950 px-4 py-3 text-xs font-bold text-white shadow-lg transition hover:bg-black active:scale-95 disabled:opacity-60 border border-slate-800 hover:border-red-500/50"
            >
              <span>{isLoading ? 'Mengautentikasi...' : 'Masuk ke Sistem'}</span>
              <ArrowRight className="h-4 w-4 text-red-500" />
            </button>
          </form>

          {/* Quick Demo Persona Switcher */}
          <div className="mt-6 border-t border-slate-800/80 pt-5">
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
                <KeyRound className="h-3.5 w-3.5 text-red-400" />
                <span>Pilih Persona Demo (1-Click Instant Login):</span>
              </div>
              <span className="text-[10px] text-slate-500">Langsung Masuk</span>
            </div>

            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {users.slice(0, 4).map(u => (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => handleQuickLogin(u)}
                  className="group flex items-center gap-2.5 rounded-2xl border border-slate-800 bg-slate-800/50 p-2 text-left transition hover:border-red-500/50 hover:bg-slate-800"
                >
                  <img
                    src={u.avatar}
                    alt={u.name}
                    className="h-8 w-8 rounded-full object-cover ring-1 ring-slate-700"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-xs font-bold text-white group-hover:text-red-400">
                      {u.name}
                    </div>
                    <div className="truncate text-[10px] text-slate-400">
                      {u.role === 'super_admin' ? '👑 Super Admin' : u.position.split('&')[0]}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Security & Compliance Badges */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-[10px] text-slate-500 border-t border-slate-800/60 pt-4">
            <span className="flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3 text-emerald-400" />
              ISO 27001 Certified
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <ShieldCheck className="h-3 w-3 text-red-400" />
              RBAC Multi-Level Access
            </span>
            <span>•</span>
            <span>End-to-End Encrypted</span>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-4 text-center text-xs text-slate-500">
        &copy; {new Date().getFullYear()} {workspaceInfo.name || 'WORKSPACE'}. Hak Cipta Dilindungi Undang-Undang.
      </footer>
    </div>
  );
};
