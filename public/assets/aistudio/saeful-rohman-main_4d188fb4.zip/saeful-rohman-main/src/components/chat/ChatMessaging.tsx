import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Paperclip,
  Smile,
  Mic,
  Hash,
  Lock,
  Plus,
  Search,
  Phone,
  Video,
  ChevronLeft,
  CheckCheck,
  Play,
  Pause,
  X,
  Users,
  Sparkles,
  SmilePlus,
  Check,
  UserPlus
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { Channel, ChatMessage, StickerData } from '../../types';

// Pre-made corporate sticker templates
const DEFAULT_PRESET_STICKERS: StickerData[] = [
  { id: 'stk_1', emoji: '🚀', text: 'Siap Laksanakan!', style: 'neon' },
  { id: 'stk_2', emoji: '✅', text: 'Approved & Done!', style: 'emerald' },
  { id: 'stk_3', emoji: '🔥', text: 'Mantap Jiwa!', style: 'gold' },
  { id: 'stk_4', emoji: '⚠️', text: 'Perlu Review Segera', style: 'stamp' },
  { id: 'stk_5', emoji: '🛵', text: 'OTW Lapangan', style: 'cyan' },
  { id: 'stk_6', emoji: '⚡', text: 'Gaskeun Bro!', style: 'neon' },
  { id: 'stk_7', emoji: '💰', text: 'Closing Deal!', style: 'gold' },
  { id: 'stk_8', emoji: '☕', text: 'Ngopi Dulu Bentar', style: 'bubble' },
  { id: 'stk_9', emoji: '🎯', text: 'Target Tercapai!', style: 'emerald' },
  { id: 'stk_10', emoji: '💪', text: 'Kerja Keras Mantap', style: 'stamp' },
  { id: 'stk_11', emoji: '🏆', text: 'Top Performer!', style: 'gold' },
  { id: 'stk_12', emoji: '🤝', text: 'Sepakat & Deal', style: 'cyan' },
];

export const ChatMessaging: React.FC = () => {
  const {
    currentUser,
    users,
    channels,
    activeChannelId,
    setActiveChannelId,
    messages,
    sendMessage,
    toggleReaction,
    createChannel,
    startDirectMessage
  } = useWorkspace();

  const [messageText, setMessageText] = useState('');
  const [searchChannel, setSearchChannel] = useState('');
  const [channelFilter, setChannelFilter] = useState<'all' | 'channels' | 'direct'>('all');
  const [isPlayingVoice, setIsPlayingVoice] = useState<string | null>(null);
  const [showChannelModal, setShowChannelModal] = useState(false);
  const [showDmModal, setShowDmModal] = useState(false);
  const [showMobileList, setShowMobileList] = useState(false);

  // Sticker modal & maker state
  const [showStickerModal, setShowStickerModal] = useState(false);
  const [stickerTab, setStickerTab] = useState<'presets' | 'create'>('presets');
  
  // Custom sticker studio state
  const [customStickerText, setCustomStickerText] = useState('KERJA KERAS 🚀');
  const [customStickerEmoji, setCustomStickerEmoji] = useState('🔥');
  const [customStickerStyle, setCustomStickerStyle] = useState<StickerData['style']>('neon');
  const [userCreatedStickers, setUserCreatedStickers] = useState<StickerData[]>(() => {
    try {
      const saved = localStorage.getItem('WORKSPACE_CUSTOM_STICKERS');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // New channel form state
  const [newChanName, setNewChanName] = useState('');
  const [newChanDesc, setNewChanDesc] = useState('');
  const [newChanPrivate, setNewChanPrivate] = useState(false);
  const [newChanMembers, setNewChanMembers] = useState<string[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Current active channel
  const activeChannel = channels.find(c => c.id === activeChannelId) || channels[0] || {
    id: 'general',
    name: 'general-announcements',
    type: 'channel',
    memberIds: []
  };
  const currentMessages = (activeChannel && messages[activeChannel.id]) || [];

  // Scroll to bottom on message updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentMessages.length, activeChannelId]);

  // Persist custom stickers
  useEffect(() => {
    try {
      localStorage.setItem('WORKSPACE_CUSTOM_STICKERS', JSON.stringify(userCreatedStickers));
    } catch (e) {
      console.error('Error saving custom stickers:', e);
    }
  }, [userCreatedStickers]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;
    sendMessage(activeChannel.id, messageText);
    setMessageText('');
  };

  const handleSendSticker = (sticker: StickerData) => {
    sendMessage(activeChannel.id, '', undefined, undefined, sticker);
    setShowStickerModal(false);
  };

  const handleCreateAndSendCustomSticker = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customStickerText.trim()) return;

    const newSticker: StickerData = {
      id: 'stk_custom_' + Date.now(),
      text: customStickerText.trim(),
      emoji: customStickerEmoji,
      style: customStickerStyle,
      authorName: currentUser.name
    };

    // Save to user collection
    setUserCreatedStickers(prev => [newSticker, ...prev]);

    // Send to current channel
    sendMessage(activeChannel.id, '', undefined, undefined, newSticker);
    setShowStickerModal(false);
  };

  const handleSendVoiceNoteMock = () => {
    sendMessage(activeChannel.id, '🎤 Pesan Suara (Voice Note)', undefined, {
      duration: '0:24',
      url: '#'
    });
  };

  const handleSendAttachmentMock = () => {
    sendMessage(activeChannel.id, '📎 Lampiran Dokumen Spesifikasi', [
      {
        name: 'Tech_Spec_Architecture_v2.pdf',
        url: '#',
        type: 'pdf',
        size: '1.8 MB'
      }
    ]);
  };

  const handleCreateChannelSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChanName.trim()) return;
    createChannel(newChanName, newChanDesc, newChanPrivate, newChanMembers);
    setNewChanName('');
    setNewChanDesc('');
    setNewChanPrivate(false);
    setNewChanMembers([]);
    setShowChannelModal(false);
  };

  // Channels filtering
  const allFiltered = channels.filter(c => {
    if (channelFilter === 'channels' && c.type !== 'channel') return false;
    if (channelFilter === 'direct' && c.type !== 'direct') return false;
    return c.name.toLowerCase().includes(searchChannel.toLowerCase());
  });

  const getDirectUser = (channel: Channel) => {
    if (channel.type !== 'direct' || !channel.otherUserId) return null;
    return users.find(u => u.id === channel.otherUserId);
  };

  const directUser = getDirectUser(activeChannel);

  // Sticker visual style renderer
  const renderStickerBadge = (sticker: StickerData, isMe: boolean) => {
    const styleClasses = {
      neon: 'from-violet-600 to-indigo-700 text-white shadow-lg shadow-indigo-500/30 border-violet-400/30 ring-2 ring-indigo-400/40',
      gold: 'from-amber-400 via-amber-500 to-yellow-600 text-slate-950 font-extrabold shadow-lg shadow-amber-500/25 border-yellow-200 ring-2 ring-amber-300',
      stamp: 'from-red-600 via-rose-600 to-red-700 text-white uppercase tracking-wider shadow-lg shadow-red-600/30 border-2 border-dashed border-red-200 ring-2 ring-red-400',
      emerald: 'from-emerald-500 to-teal-700 text-white shadow-lg shadow-emerald-500/25 border-emerald-300/40 ring-2 ring-emerald-400/40',
      cyan: 'from-sky-500 to-cyan-600 text-white shadow-lg shadow-cyan-500/25 border-cyan-300/40 ring-2 ring-cyan-400/40',
      bubble: 'from-pink-500 via-rose-500 to-purple-600 text-white shadow-lg shadow-pink-500/25 border-pink-300/40 ring-2 ring-pink-400/40'
    };

    return (
      <div
        className={`group/sticker relative inline-flex flex-col items-center justify-center gap-1.5 rounded-2xl bg-gradient-to-br px-5 py-3.5 transition-transform duration-200 hover:scale-105 select-none ${
          styleClasses[sticker.style] || styleClasses.neon
        }`}
      >
        <span className="text-3xl filter drop-shadow-sm transition-transform duration-200 group-hover/sticker:rotate-12 group-hover/sticker:scale-110">
          {sticker.emoji}
        </span>
        <span className="text-xs font-bold leading-tight text-center drop-shadow-xs max-w-[180px]">
          {sticker.text}
        </span>
        <div className="flex items-center gap-1 text-[9px] opacity-80 font-medium">
          <Sparkles className="h-2.5 w-2.5" />
          <span>{sticker.authorName ? `by ${sticker.authorName.split(' ')[0]}` : 'Stiker Tim'}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="flex h-full w-full overflow-hidden bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
      {/* Left Sidebar: Seamless Channel & DM Directory */}
      <div
        className={`flex w-full flex-col border-r border-slate-200 bg-slate-50/50 dark:border-slate-800 dark:bg-slate-900/70 md:w-80 shrink-0 ${
          showMobileList ? 'flex' : 'hidden md:flex'
        }`}
      >
        {/* Header & Quick Action Buttons */}
        <div className="border-b border-slate-200/80 p-3.5 dark:border-slate-800">
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-red-600 text-white shadow-xs">
                <Hash className="h-4 w-4" />
              </div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Chat & Diskusi
              </h2>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setShowDmModal(true)}
                className="flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-2 py-1 text-[11px] font-semibold text-slate-700 shadow-2xs hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                title="Kirim Pesan Langsung (DM)"
              >
                <UserPlus className="h-3 w-3 text-red-600" />
                <span>DM</span>
              </button>
              <button
                onClick={() => setShowChannelModal(true)}
                className="flex items-center gap-1 rounded-xl bg-red-600 px-2 py-1 text-[11px] font-bold text-white shadow-xs hover:bg-red-700"
                title="Buat Saluran Baru"
              >
                <Plus className="h-3 w-3" />
                <span>Channel</span>
              </button>
            </div>
          </div>

          {/* Elongated Search Channel */}
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Cari obrolan atau rekan kerja..."
              value={searchChannel}
              onChange={e => setSearchChannel(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-white pl-8 pr-7 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            />
            {searchChannel && (
              <button
                onClick={() => setSearchChannel('')}
                className="absolute right-2 top-2 text-slate-400 hover:text-slate-600"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {/* Unified Filter Tabs: Semua, Channel, DM */}
          <div className="mt-2.5 flex items-center gap-1 rounded-xl bg-slate-200/60 p-0.5 dark:bg-slate-800/80">
            <button
              onClick={() => setChannelFilter('all')}
              className={`flex-1 rounded-lg py-1 text-[11px] font-semibold transition ${
                channelFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-2xs dark:bg-slate-700 dark:text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
              }`}
            >
              Semua
            </button>
            <button
              onClick={() => setChannelFilter('channels')}
              className={`flex-1 rounded-lg py-1 text-[11px] font-semibold transition ${
                channelFilter === 'channels'
                  ? 'bg-white text-slate-900 shadow-2xs dark:bg-slate-700 dark:text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
              }`}
            >
              Channels
            </button>
            <button
              onClick={() => setChannelFilter('direct')}
              className={`flex-1 rounded-lg py-1 text-[11px] font-semibold transition ${
                channelFilter === 'direct'
                  ? 'bg-white text-slate-900 shadow-2xs dark:bg-slate-700 dark:text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
              }`}
            >
              Pesan DM
            </button>
          </div>
        </div>

        {/* Unified Conversation Scroll Area */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {allFiltered.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              Tidak ada obrolan ditemukan.
            </div>
          ) : (
            allFiltered.map(c => {
              const isActive = c.id === activeChannel.id;
              const isDirect = c.type === 'direct';
              const user = isDirect ? getDirectUser(c) : null;

              return (
                <button
                  key={c.id}
                  onClick={() => {
                    setActiveChannelId(c.id);
                    setShowMobileList(false);
                  }}
                  className={`group flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left text-xs transition duration-150 ${
                    isActive
                      ? 'bg-red-50/90 text-red-700 shadow-2xs dark:bg-red-950/40 dark:text-red-300'
                      : 'text-slate-700 hover:bg-slate-100/80 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  {isDirect ? (
                    <div className="relative shrink-0">
                      <img
                        src={user?.avatar || currentUser.avatar}
                        alt={c.name}
                        className="h-8 w-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                      />
                      <span
                        className={`absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-white dark:ring-slate-900 ${
                          user?.status === 'online'
                            ? 'bg-emerald-500'
                            : user?.status === 'busy'
                            ? 'bg-red-500'
                            : 'bg-amber-500'
                        }`}
                      />
                    </div>
                  ) : (
                    <div
                      className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl transition ${
                        isActive
                          ? 'bg-red-600 text-white'
                          : 'bg-slate-200 text-slate-600 group-hover:bg-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:group-hover:bg-slate-700'
                      }`}
                    >
                      {c.isPrivate ? (
                        <Lock className="h-3.5 w-3.5" />
                      ) : (
                        <Hash className="h-4 w-4" />
                      )}
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span
                        className={`truncate font-semibold ${
                          isActive ? 'text-red-700 dark:text-red-300 font-bold' : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {isDirect ? c.name : `#${c.name}`}
                      </span>
                      {c.lastMessageTime && (
                        <span className="shrink-0 text-[10px] text-slate-400">
                          {c.lastMessageTime}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center justify-between mt-0.5">
                      <span className="truncate text-[11px] text-slate-500 dark:text-slate-400">
                        {c.lastMessage || (isDirect ? user?.position : c.description) || 'Mulai obrolan...'}
                      </span>
                      {c.unreadCount ? (
                        <span className="shrink-0 rounded-full bg-red-600 px-1.5 py-0.2 text-[9px] font-bold text-white">
                          {c.unreadCount}
                        </span>
                      ) : null}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Right Column: Active Conversation Stream */}
      <div
        className={`flex flex-1 flex-col overflow-hidden bg-slate-50/30 dark:bg-slate-950/40 ${
          showMobileList ? 'hidden md:flex' : 'flex'
        }`}
      >
        {/* Chat Header */}
        <div className="flex h-16 items-center justify-between border-b border-slate-200 bg-white px-4 dark:border-slate-800 dark:bg-slate-900 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setShowMobileList(true)}
              className="rounded-xl p-1.5 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 md:hidden"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>

            {activeChannel.type === 'channel' ? (
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-100 text-red-600 dark:bg-red-950/60 dark:text-red-300 shrink-0">
                  <Hash className="h-5 w-5" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="truncate text-sm font-bold text-slate-900 dark:text-white">
                      #{activeChannel.name}
                    </span>
                    {activeChannel.isPrivate && (
                      <span className="rounded-md bg-slate-100 px-1.5 py-0.5 text-[9px] font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                        Privat
                      </span>
                    )}
                  </div>
                  <p className="truncate text-[11px] text-slate-500 dark:text-slate-400">
                    {activeChannel.description || 'Saluran diskusi terpadu anggota tim'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="relative shrink-0">
                  <img
                    src={directUser?.avatar || currentUser.avatar}
                    alt={activeChannel.name}
                    className="h-9 w-9 rounded-full object-cover"
                  />
                  <span
                    className={`absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-white dark:ring-slate-900 ${
                      directUser?.status === 'online'
                        ? 'bg-emerald-500'
                        : directUser?.status === 'busy'
                        ? 'bg-red-500'
                        : 'bg-amber-500'
                    }`}
                  />
                </div>
                <div className="min-w-0">
                  <div className="truncate text-sm font-bold text-slate-900 dark:text-white">
                    {activeChannel.name}
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                      {directUser?.status === 'online' ? '● Online' : 'Sedang Sibuk'}
                    </span>
                    <span className="text-slate-400">•</span>
                    <span className="truncate text-slate-500 dark:text-slate-400">
                      {directUser?.position || 'Anggota Tim'}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Quick Communication Actions & Sticker Shortcut */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={() => {
                setShowStickerModal(true);
                setStickerTab('presets');
              }}
              className="flex items-center gap-1.5 rounded-xl border border-red-200 bg-red-50/70 px-2.5 py-1.5 text-xs font-bold text-red-600 shadow-2xs transition hover:bg-red-100 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300"
              title="Koleksi & Bikin Stiker Baru"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Stiker</span>
            </button>

            <button
              onClick={() => alert(`Memulai panggilan suara instan dengan ${activeChannel.name}`)}
              className="rounded-xl p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
              title="Panggilan Suara"
            >
              <Phone className="h-4 w-4" />
            </button>
            <button
              onClick={() => alert(`Memulai panggilan video HD dengan ${activeChannel.name}`)}
              className="rounded-xl p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
              title="Panggilan Video HD"
            >
              <Video className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Message Thread Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {currentMessages.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center text-slate-400">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800 mb-3">
                <Hash className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
                Belum ada percakapan di #{activeChannel.name}
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">
                Kirim pesan, lampiran, dokumen, atau stiker penyemangat untuk memulai koordinasi bersama tim!
              </p>
              <button
                onClick={() => {
                  setShowStickerModal(true);
                  setStickerTab('presets');
                }}
                className="mt-3.5 inline-flex items-center gap-1.5 rounded-xl bg-red-600 px-3.5 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-red-700"
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>Kirim Stiker Pembuka 🎉</span>
              </button>
            </div>
          ) : (
            currentMessages.map(msg => {
              const isMe = msg.senderId === currentUser.id;

              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 group/msg ${isMe ? 'justify-end' : 'justify-start'}`}
                >
                  {!isMe && (
                    <img
                      src={msg.senderAvatar}
                      alt={msg.senderName}
                      className="h-8 w-8 rounded-full object-cover shrink-0 mt-0.5 ring-1 ring-slate-200 dark:ring-slate-700"
                    />
                  )}

                  <div className={`max-w-[82%] sm:max-w-[70%] space-y-1 ${isMe ? 'items-end' : 'items-start'}`}>
                    {!isMe && (
                      <div className="text-[11px] font-bold text-slate-600 dark:text-slate-300">
                        {msg.senderName}
                      </div>
                    )}

                    {/* Sticker Content Rendering */}
                    {msg.sticker ? (
                      <div className="my-1">
                        {renderStickerBadge(msg.sticker, isMe)}
                      </div>
                    ) : (
                      <div
                        className={`relative rounded-2xl px-4 py-2.5 text-xs shadow-2xs leading-relaxed transition-all ${
                          isMe
                            ? 'bg-red-600 text-white rounded-tr-xs'
                            : 'bg-white text-slate-800 dark:bg-slate-800 dark:text-slate-100 border border-slate-200/90 dark:border-slate-700/70 rounded-tl-xs'
                        }`}
                      >
                        {/* Voice Note Player Mock */}
                        {msg.voiceNote && (
                          <div className="flex items-center gap-3 py-1">
                            <button
                              onClick={() =>
                                setIsPlayingVoice(isPlayingVoice === msg.id ? null : msg.id)
                              }
                              className={`flex h-8 w-8 items-center justify-center rounded-full transition ${
                                isMe ? 'bg-white text-red-600' : 'bg-red-600 text-white'
                              }`}
                            >
                              {isPlayingVoice === msg.id ? (
                                <Pause className="h-3.5 w-3.5" />
                              ) : (
                                <Play className="h-3.5 w-3.5 ml-0.5" />
                              )}
                            </button>
                            <div className="flex-1">
                              <div className="flex items-center gap-1 h-4">
                                <span className="w-1 bg-current h-2 rounded-full animate-pulse" />
                                <span className="w-1 bg-current h-4 rounded-full" />
                                <span className="w-1 bg-current h-3 rounded-full" />
                                <span className="w-1 bg-current h-5 rounded-full" />
                                <span className="w-1 bg-current h-2 rounded-full" />
                                <span className="w-1 bg-current h-4 rounded-full" />
                              </div>
                              <span className="text-[10px] opacity-80">{msg.voiceNote.duration}</span>
                            </div>
                          </div>
                        )}

                        {/* Standard Text Message */}
                        {msg.content && <p className="whitespace-pre-wrap">{msg.content}</p>}

                        {/* Attachments */}
                        {msg.attachments && msg.attachments.length > 0 && (
                          <div className="mt-2 space-y-1">
                            {msg.attachments.map((att, i) => (
                              <div
                                key={i}
                                className={`flex items-center gap-2 rounded-xl p-2 text-[11px] ${
                                  isMe
                                    ? 'bg-red-700/60 text-white'
                                    : 'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-200'
                                }`}
                              >
                                <Paperclip className="h-3.5 w-3.5" />
                                <span className="font-semibold truncate">{att.name}</span>
                                <span className="text-[9px] opacity-75">{att.size}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Reactions & Timestamp */}
                    <div className="flex items-center gap-2 text-[10px] text-slate-400">
                      <span>Baru saja</span>
                      {isMe && <CheckCheck className="h-3 w-3 text-red-500" />}

                      {/* Reaction Badges */}
                      {msg.reactions && msg.reactions.length > 0 && (
                        <div className="flex items-center gap-1">
                          {msg.reactions.map(r => (
                            <button
                              key={r.emoji}
                              onClick={() => toggleReaction(activeChannel.id, msg.id, r.emoji)}
                              className={`flex items-center gap-0.5 rounded-full border px-1.5 py-0.2 text-[10px] ${
                                r.userIds.includes(currentUser.id)
                                  ? 'border-red-400 bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300'
                                  : 'border-slate-200 bg-white text-slate-600 dark:border-slate-700 dark:bg-slate-800'
                              }`}
                            >
                              <span>{r.emoji}</span>
                              <span>{r.userIds.length}</span>
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Quick Reactions on Hover */}
                      <button
                        onClick={() => toggleReaction(activeChannel.id, msg.id, '👍')}
                        className="opacity-0 group-hover/msg:opacity-100 transition rounded p-0.5 hover:bg-slate-200 dark:hover:bg-slate-700"
                        title="Tambah jempol"
                      >
                        👍
                      </button>
                      <button
                        onClick={() => toggleReaction(activeChannel.id, msg.id, '🔥')}
                        className="opacity-0 group-hover/msg:opacity-100 transition rounded p-0.5 hover:bg-slate-200 dark:hover:bg-slate-700"
                        title="Tambah api"
                      >
                        🔥
                      </button>
                      <button
                        onClick={() => toggleReaction(activeChannel.id, msg.id, '❤️')}
                        className="opacity-0 group-hover/msg:opacity-100 transition rounded p-0.5 hover:bg-slate-200 dark:hover:bg-slate-700"
                        title="Tambah hati"
                      >
                        ❤️
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input Bar (Seamless pill bar) */}
        <form
          onSubmit={handleSend}
          className="border-t border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900 shrink-0"
        >
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={handleSendAttachmentMock}
              className="rounded-xl p-2 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
              title="Unggah Dokumen Lampiran"
            >
              <Paperclip className="h-4 w-4" />
            </button>

            <button
              type="button"
              onClick={handleSendVoiceNoteMock}
              className="rounded-xl p-2 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
              title="Kirim Pesan Suara (Voice Note)"
            >
              <Mic className="h-4 w-4" />
            </button>

            {/* Sticker Drawer Trigger */}
            <button
              type="button"
              onClick={() => setShowStickerModal(true)}
              className="flex items-center gap-1 rounded-xl p-2 text-slate-600 hover:bg-red-50 hover:text-red-600 dark:text-slate-300 dark:hover:bg-red-950/40 dark:hover:text-red-300 transition"
              title="Buka Stiker & Bikin Stiker Baru"
            >
              <SmilePlus className="h-4 w-4 text-red-600" />
            </button>

            <input
              type="text"
              placeholder={`Tulis pesan di #${activeChannel.name}...`}
              value={messageText}
              onChange={e => setMessageText(e.target.value)}
              className="flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-800 placeholder-slate-400 focus:border-red-500 focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            />

            <button
              type="submit"
              disabled={!messageText.trim()}
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-600 text-white shadow-xs transition hover:bg-red-700 disabled:opacity-40 shrink-0"
              title="Kirim Pesan"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </form>
      </div>

      {/* STICKER PICKER & MAKER STUDIO MODAL */}
      {showStickerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-3xl bg-white p-5 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-red-100 text-red-600 dark:bg-red-950 dark:text-red-300">
                  <Sparkles className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Stiker Korporat & Pembuat Stiker
                  </h3>
                  <p className="text-[10px] text-slate-400">
                    Kirim stiker ekspresif atau rancang stiker custom khas tim kamu!
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowStickerModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Studio Navigation Tabs */}
            <div className="mt-3 flex items-center gap-1 rounded-2xl bg-slate-100 p-1 dark:bg-slate-800">
              <button
                onClick={() => setStickerTab('presets')}
                className={`flex-1 rounded-xl py-1.5 text-xs font-bold transition ${
                  stickerTab === 'presets'
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                }`}
              >
                Katalog Stiker Cepat
              </button>
              <button
                onClick={() => setStickerTab('create')}
                className={`flex-1 rounded-xl py-1.5 text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  stickerTab === 'create'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                }`}
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>✨ Bikin Stiker Baru</span>
              </button>
            </div>

            {/* TAB 1: PRESET & SAVED STICKERS */}
            {stickerTab === 'presets' && (
              <div className="mt-4 max-h-[380px] overflow-y-auto pr-1 space-y-4">
                {/* User's custom made stickers */}
                {userCreatedStickers.length > 0 && (
                  <div>
                    <div className="mb-2 flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                      <span>Stiker Buatanmu ({userCreatedStickers.length})</span>
                      <button
                        onClick={() => setUserCreatedStickers([])}
                        className="text-[10px] font-medium text-slate-400 hover:text-red-500"
                      >
                        Reset
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                      {userCreatedStickers.map(stk => (
                        <button
                          key={stk.id}
                          onClick={() => handleSendSticker(stk)}
                          className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-slate-50 p-3 hover:border-red-400 hover:bg-red-50/40 dark:border-slate-800 dark:bg-slate-800/60 dark:hover:border-red-500/50 transition cursor-pointer"
                        >
                          {renderStickerBadge(stk, false)}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Popular corporate presets */}
                <div>
                  <div className="mb-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                    Stiker Siap Pakai
                  </div>
                  <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                    {DEFAULT_PRESET_STICKERS.map(stk => (
                      <button
                        key={stk.id}
                        onClick={() => handleSendSticker(stk)}
                        className="flex flex-col items-center justify-center rounded-2xl border border-slate-200/80 bg-slate-50/70 p-3 hover:border-red-400 hover:bg-red-50/30 dark:border-slate-800 dark:bg-slate-800/40 dark:hover:border-red-500/50 transition cursor-pointer"
                      >
                        {renderStickerBadge(stk, false)}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: INTERACTIVE STICKER MAKER STUDIO */}
            {stickerTab === 'create' && (
              <form onSubmit={handleCreateAndSendCustomSticker} className="mt-4 space-y-4">
                {/* Live Preview Display */}
                <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-slate-50/80 p-5 dark:border-slate-700 dark:bg-slate-800/50">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Pratinjau Hasil Stiker
                  </div>
                  {renderStickerBadge(
                    {
                      id: 'preview',
                      text: customStickerText || 'CONTOH TEKS STIKER',
                      emoji: customStickerEmoji,
                      style: customStickerStyle,
                      authorName: currentUser.name
                    },
                    true
                  )}
                </div>

                {/* Input Slogan / Text */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Teks Stiker (Slogan/Kata-kata)
                  </label>
                  <input
                    type="text"
                    maxLength={28}
                    placeholder="misal: ACC BOS 🌟 atau SIAP KAWAL!"
                    value={customStickerText}
                    onChange={e => setCustomStickerText(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                  <div className="mt-1 flex justify-between text-[10px] text-slate-400">
                    <span>Maksimal 28 karakter untuk tampilan terbaik</span>
                    <span>{customStickerText.length}/28</span>
                  </div>
                </div>

                {/* Select Emoji */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Pilih Emotikon Utama
                  </label>
                  <div className="flex flex-wrap gap-1.5 p-2 rounded-xl bg-slate-100 dark:bg-slate-800">
                    {['🔥', '🚀', '✅', '⚡', '💡', '🎯', '💰', '🏆', '☕', '🛵', '💪', '🤝', '💯', '🦁', '⭐', '🍕'].map(
                      emo => (
                        <button
                          key={emo}
                          type="button"
                          onClick={() => setCustomStickerEmoji(emo)}
                          className={`flex h-8 w-8 items-center justify-center rounded-lg text-lg transition ${
                            customStickerEmoji === emo
                              ? 'bg-white shadow-xs scale-110 ring-2 ring-red-500 dark:bg-slate-700'
                              : 'hover:bg-white/60 dark:hover:bg-slate-700/60'
                          }`}
                        >
                          {emo}
                        </button>
                      )
                    )}
                  </div>
                </div>

                {/* Select Style Theme */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Tema Gaya Visual
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { key: 'neon', label: 'Neon Cyber', color: 'bg-violet-600' },
                      { key: 'gold', label: 'Gold Luxury', color: 'bg-amber-500' },
                      { key: 'stamp', label: 'Red Stamp', color: 'bg-red-600' },
                      { key: 'emerald', label: 'Emerald OK', color: 'bg-emerald-600' },
                      { key: 'cyan', label: 'Cyan Sky', color: 'bg-cyan-600' },
                      { key: 'bubble', label: 'Pink Pop', color: 'bg-pink-600' }
                    ].map(styleOpt => (
                      <button
                        key={styleOpt.key}
                        type="button"
                        onClick={() => setCustomStickerStyle(styleOpt.key as StickerData['style'])}
                        className={`flex items-center gap-2 rounded-xl border p-2 text-left text-xs transition ${
                          customStickerStyle === styleOpt.key
                            ? 'border-red-500 bg-red-50/50 font-bold text-red-700 dark:border-red-400 dark:bg-red-950/40 dark:text-red-300 ring-1 ring-red-500'
                            : 'border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
                        }`}
                      >
                        <span className={`h-3 w-3 rounded-full ${styleOpt.color}`} />
                        <span className="truncate">{styleOpt.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Submit Action */}
                <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setStickerTab('presets')}
                    className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={!customStickerText.trim()}
                    className="flex items-center gap-1.5 rounded-xl bg-red-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-red-700 active:scale-95 disabled:opacity-40"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    <span>Kirim & Simpan Stiker</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* NEW DIRECT MESSAGE MODAL */}
      {showDmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-sm rounded-3xl bg-white p-5 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Mulai Pesan Langsung (DM)
              </h3>
              <button
                onClick={() => setShowDmModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-3 max-h-64 overflow-y-auto space-y-1">
              {users
                .filter(u => u.id !== currentUser.id)
                .map(user => (
                  <button
                    key={user.id}
                    onClick={() => {
                      startDirectMessage(user.id);
                      setShowDmModal(false);
                      setShowMobileList(false);
                    }}
                    className="flex w-full items-center gap-3 rounded-2xl p-2 text-left hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                  >
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="h-8 w-8 rounded-full object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {user.name}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">
                        {user.position} • {user.department}
                      </div>
                    </div>
                  </button>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* CREATE CHANNEL MODAL */}
      {showChannelModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Buat Saluran Tim Baru
              </h3>
              <button
                onClick={() => setShowChannelModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleCreateChannelSubmit} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Nama Saluran (Channel)
                </label>
                <div className="relative mt-1">
                  <span className="absolute left-3 top-2 text-xs font-bold text-slate-400">#</span>
                  <input
                    type="text"
                    placeholder="project-phoenix atau produk-baru"
                    value={newChanName}
                    onChange={e => setNewChanName(e.target.value.toLowerCase().replace(/\s+/g, '-'))}
                    required
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-7 pr-3 py-2 text-xs font-semibold focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Deskripsi Saluran
                </label>
                <textarea
                  placeholder="Tujuan atau cakupan diskusi saluran ini..."
                  value={newChanDesc}
                  onChange={e => setNewChanDesc(e.target.value)}
                  rows={2}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="privCheck"
                  checked={newChanPrivate}
                  onChange={e => setNewChanPrivate(e.target.checked)}
                  className="rounded text-red-600 focus:ring-red-500"
                />
                <label htmlFor="privCheck" className="text-xs text-slate-700 dark:text-slate-300">
                  Jadikan Saluran Privat (Hanya anggota terdaftar)
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowChannelModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-400"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-red-600 px-4 py-2 text-xs font-bold text-white hover:bg-red-700 shadow-xs"
                >
                  Buat Saluran
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
