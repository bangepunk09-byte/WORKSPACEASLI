import React from 'react';
import {
  CheckCircle2,
  Clock,
  AlertTriangle,
  PlayCircle,
  Calendar,
  ArrowUpRight,
  Plus,
  Video,
  FileText,
  MessageSquare,
  Users,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  CheckSquare
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { ProductivityTrendsChart } from './ProductivityTrendsChart';

export const HomeDashboard: React.FC = () => {
  const {
    currentUser,
    tasks,
    meetings,
    posts,
    setActiveTab,
    setQuickActionModal,
    moveTaskStatus
  } = useWorkspace();

  // Task metrics
  const todoTasks = tasks.filter(t => t.status === 'todo');
  const inProgressTasks = tasks.filter(t => t.status === 'in_progress');
  const reviewTasks = tasks.filter(t => t.status === 'review');
  const doneTasks = tasks.filter(t => t.status === 'done');
  
  // Overdue / Urgent tasks
  const todayStr = '2026-11-01';
  const urgentTasks = tasks.filter(
    t => t.priority === 'urgent' && t.status !== 'done'
  );
  const overdueTasks = tasks.filter(
    t => t.deadline < todayStr && t.status !== 'done'
  );

  // Today & upcoming meetings
  const upcomingMeetings = [...meetings]
    .sort((a, b) => (a.date + a.startTime).localeCompare(b.date + b.startTime))
    .slice(0, 3);

  // Recent team announcements & posts
  const recentPosts = posts.slice(0, 3);

  const currentDateFormatted = new Intl.DateTimeFormat('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(new Date());

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 p-6 text-white shadow-xl transition-all duration-300 hover:shadow-2xl">
        <div className="relative z-10 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-red-400">
              <Sparkles className="h-4 w-4 animate-pulse-subtle" />
              <span>{currentDateFormatted}</span>
            </div>
            <h1 className="mt-1 text-2xl font-extrabold tracking-tight sm:text-3xl">
              Selamat Datang Kembali, {currentUser.name.split(' ')[0]} 👋
            </h1>
            <p className="mt-1 max-w-xl text-xs text-slate-300 sm:text-sm">
              Ringkasan pekerjaan dan koordinasi harian tim Anda di <span className="font-semibold text-white">WORKSPACE Corporate Hub</span>.
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => setQuickActionModal('task')}
              className="flex items-center gap-2 rounded-2xl bg-red-600 px-4 py-2.5 text-xs font-bold text-white shadow-md shadow-red-900/40 transition-all hover:bg-red-700 hover:shadow-lg active:scale-95"
            >
              <Plus className="h-4 w-4" />
              <span>Buat Task</span>
            </button>
            <button
              onClick={() => setQuickActionModal('meeting')}
              className="flex items-center gap-2 rounded-2xl bg-slate-700/80 px-4 py-2.5 text-xs font-bold text-white transition-all hover:bg-slate-700 active:scale-95 backdrop-blur-xs"
            >
              <Calendar className="h-4 w-4" />
              <span>Jadwal Meeting</span>
            </button>
          </div>
        </div>

        {/* Subtle decorative background glow */}
        <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-red-600/15 blur-3xl" />
        <div className="pointer-events-none absolute left-1/3 -bottom-16 h-48 w-48 rounded-full bg-indigo-600/20 blur-2xl" />
      </div>

      {/* Task Statistics Cards */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        {/* To Do */}
        <div
          onClick={() => setActiveTab('tasks')}
          className="group cursor-pointer rounded-3xl border border-slate-200/90 bg-white p-4.5 shadow-xs transition-all duration-200 hover:-translate-y-1 hover:border-blue-400 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">To Do</span>
            <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400 transition-transform group-hover:scale-110">
              <Clock className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-black text-slate-900 dark:text-white">
            {todoTasks.length}
          </div>
          <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
            <span>Siap dikerjakan</span>
            <ChevronRight className="h-3.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
          </div>
        </div>

        {/* In Progress */}
        <div
          onClick={() => setActiveTab('tasks')}
          className="group cursor-pointer rounded-3xl border border-slate-200/90 bg-white p-4.5 shadow-xs transition-all duration-200 hover:-translate-y-1 hover:border-amber-400 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">In Progress</span>
            <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400 transition-transform group-hover:scale-110">
              <PlayCircle className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-black text-slate-900 dark:text-white">
            {inProgressTasks.length}
          </div>
          <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
            <span>Sedang berjalan aktif</span>
            <ChevronRight className="h-3.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
          </div>
        </div>

        {/* Completed */}
        <div
          onClick={() => setActiveTab('tasks')}
          className="group cursor-pointer rounded-3xl border border-slate-200/90 bg-white p-4.5 shadow-xs transition-all duration-200 hover:-translate-y-1 hover:border-emerald-400 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">Completed</span>
            <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 transition-transform group-hover:scale-110">
              <CheckCircle2 className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-black text-slate-900 dark:text-white">
            {doneTasks.length}
          </div>
          <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
            <span>Tugas selesai</span>
            <ChevronRight className="h-3.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
          </div>
        </div>

        {/* Overdue / Urgent */}
        <div
          onClick={() => setActiveTab('tasks')}
          className="group cursor-pointer rounded-3xl border border-red-200 bg-red-50/50 p-4.5 shadow-xs transition-all duration-200 hover:-translate-y-1 hover:border-red-400 hover:shadow-md dark:border-red-900/60 dark:bg-red-950/20"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-red-700 dark:text-red-400">Urgent / Overdue</span>
            <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-red-100 text-red-600 dark:bg-red-900/60 dark:text-red-300 transition-transform group-hover:scale-110">
              <AlertTriangle className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-black text-red-700 dark:text-red-400">
            {urgentTasks.length + overdueTasks.length}
          </div>
          <div className="mt-1 flex items-center justify-between text-[11px] text-red-600 dark:text-red-300 font-medium">
            <span>Perlu perhatian segera</span>
            <ChevronRight className="h-3.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
          </div>
        </div>
      </div>

      {/* Main Grid: Left (Recharts Productivity + My Urgent Tasks) & Right (Meetings + Announcements) */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Left 2 Cols */}
        <div className="space-y-6 lg:col-span-2">
          {/* Recharts Productivity Component */}
          <ProductivityTrendsChart />

          {/* Urgent Deadlines & Work in Progress */}
          <div className="rounded-3xl border border-slate-200/90 bg-white p-5 shadow-xs transition-colors dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CheckSquare className="h-4 w-4 text-red-600" />
                Prioritas & Tenggat Waktu Terdekat
              </h2>
              <button
                onClick={() => setActiveTab('tasks')}
                className="text-xs font-semibold text-slate-500 hover:text-red-600 dark:hover:text-red-400 transition"
              >
                Lihat Semua ({tasks.length})
              </button>
            </div>

            <div className="space-y-3">
              {tasks
                .filter(t => t.status !== 'done')
                .slice(0, 4)
                .map(task => {
                  const completedChecklist = task.checklists.filter(c => c.completed).length;
                  const totalChecklist = task.checklists.length;
                  const progressPct = totalChecklist > 0 ? Math.round((completedChecklist / totalChecklist) * 100) : 40;

                  return (
                    <div
                      key={task.id}
                      className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-slate-100 bg-slate-50/70 p-3.5 transition-all duration-150 hover:border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-800/40"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={`rounded-md px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                              task.priority === 'urgent'
                                ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300'
                                : task.priority === 'high'
                                ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                                : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                            }`}
                          >
                            {task.priority}
                          </span>
                          <span className="text-[11px] text-slate-400 font-medium">{task.project}</span>
                        </div>
                        <h4 className="mt-1 text-xs font-bold text-slate-900 dark:text-white truncate">
                          {task.title}
                        </h4>
                        <div className="mt-2 flex items-center gap-3 text-[11px] text-slate-500">
                          <span>Deadline: {task.deadline}</span>
                          <span>•</span>
                          <span>Checklist: {completedChecklist}/{totalChecklist} ({progressPct}%)</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-center">
                        <button
                          onClick={() => moveTaskStatus(task.id, 'done')}
                          className="flex items-center gap-1.5 rounded-xl bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700 border border-emerald-200 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800 transition active:scale-95"
                          title="Tandai Selesai Langsung"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>Selesai</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>

        {/* Right Col: Meetings & Social Feed Highlights */}
        <div className="space-y-6">
          {/* Upcoming Meetings Schedule */}
          <div className="rounded-3xl border border-slate-200/90 bg-white p-5 shadow-xs transition-colors dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Calendar className="h-4 w-4 text-red-600" />
                Jadwal Meeting Terdekat
              </h2>
              <button
                onClick={() => setActiveTab('meetings')}
                className="text-xs font-semibold text-slate-500 hover:text-red-600 dark:hover:text-red-400 transition"
              >
                Kalender
              </button>
            </div>

            <div className="space-y-3">
              {upcomingMeetings.map(m => (
                <div
                  key={m.id}
                  className="rounded-2xl border border-slate-100 bg-slate-50/70 p-3.5 transition-all duration-150 hover:bg-slate-100/70 dark:border-slate-800 dark:bg-slate-800/50"
                >
                  <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
                    <span className="text-red-600 dark:text-red-400 font-mono">
                      {m.startTime} - {m.endTime} WIB
                    </span>
                    <span className="text-[10px] font-semibold bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded-full">
                      {m.date === '2026-11-02' ? 'Besok' : m.date}
                    </span>
                  </div>
                  <h4 className="mt-1.5 text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                    {m.title}
                  </h4>
                  <p className="mt-1 text-[11px] text-slate-500 line-clamp-1">
                    📍 {m.location}
                  </p>

                  <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                    <div className="flex -space-x-1.5 overflow-hidden">
                      {m.attendees.slice(0, 4).map(att => (
                        <img
                          key={att.userId}
                          src={att.avatar}
                          alt={att.name}
                          title={att.name}
                          className="h-6 w-6 rounded-full object-cover ring-2 ring-white dark:ring-slate-800"
                        />
                      ))}
                    </div>
                    {m.meetLink && (
                      <a
                        href={m.meetLink}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1 rounded-xl bg-red-600 px-2.5 py-1 text-[11px] font-bold text-white hover:bg-red-700 transition active:scale-95"
                      >
                        <Video className="h-3 w-3" />
                        <span>Gabung</span>
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Social Feed Announcement Pin */}
          <div className="rounded-3xl border border-slate-200/90 bg-white p-5 shadow-xs transition-colors dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-red-600" />
                Feed & Pengumuman Penting
              </h2>
              <button
                onClick={() => setActiveTab('feed')}
                className="text-xs font-semibold text-slate-500 hover:text-red-600 dark:hover:text-red-400 transition"
              >
                Buka Feed
              </button>
            </div>

            <div className="space-y-3">
              {recentPosts.map(p => (
                <div
                  key={p.id}
                  onClick={() => setActiveTab('feed')}
                  className="cursor-pointer rounded-2xl border border-slate-100 bg-slate-50/60 p-3.5 transition-all duration-150 hover:border-slate-300 dark:border-slate-800 dark:bg-slate-800/40"
                >
                  <div className="flex items-center gap-2">
                    <img
                      src={p.authorAvatar}
                      alt={p.authorName}
                      className="h-6 w-6 rounded-full object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-xs font-bold text-slate-800 dark:text-slate-100">
                        {p.authorName}
                      </div>
                    </div>
                    {p.isPinned && (
                      <span className="rounded-full bg-red-100 px-1.5 py-0.5 text-[9px] font-bold text-red-700 dark:bg-red-950 dark:text-red-300">
                        Pinned
                      </span>
                    )}
                  </div>
                  <p className="mt-2 text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                    {p.content}
                  </p>
                  <div className="mt-2 text-[10px] text-slate-400">
                    ❤️ {p.likes.length} Suka • 💬 {p.comments.length} Komentar
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
