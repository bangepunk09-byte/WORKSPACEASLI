import React, { useState } from 'react';
import {
  Kanban,
  List,
  Calendar as CalendarIcon,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  MoreVertical,
  CheckSquare,
  MessageSquare,
  Paperclip,
  User,
  ChevronDown,
  Layers,
  ArrowUpDown,
  Trash2,
  X,
  Flag,
  FileBarChart,
  ShieldAlert,
  Send,
  AlertTriangle,
  FileText,
  Building2,
  Lock,
  Sparkles,
  Printer
} from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { Task, TaskStatus, TaskPriority, TaskCheckpoint, TaskReportItem } from '../../types';

// Group / Division Definitions
interface GroupMeta {
  id: string;
  name: string;
  departmentMatch: string;
  color: string;
}

const TASK_GROUPS: GroupMeta[] = [
  { id: 'tech', name: 'Technology & Engineering', departmentMatch: 'Technology & Engineering', color: 'bg-blue-600' },
  { id: 'product', name: 'Product & Design', departmentMatch: 'Product & Design', color: 'bg-purple-600' },
  { id: 'hr', name: 'People Operations & HR', departmentMatch: 'People Operations & Culture', color: 'bg-emerald-600' },
  { id: 'marketing', name: 'Marketing & Brand', departmentMatch: 'Marketing & Brand', color: 'bg-amber-600' },
  { id: 'finance', name: 'Finance & Legal', departmentMatch: 'Finance & Legal', color: 'bg-rose-600' }
];

export const TaskManagement: React.FC = () => {
  const {
    currentUser,
    users,
    tasks,
    selectedTaskGroup,
    setSelectedTaskGroup,
    moveTaskStatus,
    setQuickActionModal,
    deleteTask,
    toggleChecklistItem,
    toggleTaskCheckpoint,
    addTaskCheckpoint,
    addTaskReport
  } = useWorkspace();

  const isSuperAdmin = currentUser.role === 'super_admin';

  // Determine user's home group ID based on their department
  const userHomeGroup = TASK_GROUPS.find(g =>
    currentUser.department.toLowerCase().includes(g.departmentMatch.toLowerCase()) ||
    g.departmentMatch.toLowerCase().includes(currentUser.department.toLowerCase())
  ) || TASK_GROUPS[0];

  // Active group
  const activeGroupId = selectedTaskGroup === 'all' && isSuperAdmin ? 'all' : (selectedTaskGroup || userHomeGroup.id);

  // Access check: Super admin can access anything. Others can only access their home group.
  const hasAccessToCurrentGroup = isSuperAdmin || activeGroupId === userHomeGroup.id || activeGroupId === 'all';

  const [viewMode, setViewMode] = useState<'kanban' | 'list' | 'calendar'>('kanban');
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [assigneeFilter, setAssigneeFilter] = useState<string>('all');
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  // Mini Report Modal state
  const [showReportModal, setShowReportModal] = useState(false);

  // New Checkpoint form inside task modal
  const [newCheckpointTitle, setNewCheckpointTitle] = useState('');
  const [newCheckpointDate, setNewCheckpointDate] = useState('');

  // New Progress Report / Note form inside task modal
  const [reportType, setReportType] = useState<'progress_update' | 'blocker' | 'note'>('progress_update');
  const [reportContent, setReportContent] = useState('');

  // Drag and Drop state
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);

  // Filter tasks based on group
  const groupFilteredTasks = tasks.filter(t => {
    if (activeGroupId === 'all') return true;
    return t.groupId === activeGroupId || t.assigneeDept === TASK_GROUPS.find(g => g.id === activeGroupId)?.departmentMatch;
  });

  // Filter tasks based on search & selectors
  const filteredTasks = groupFilteredTasks.filter(t => {
    if (priorityFilter !== 'all' && t.priority !== priorityFilter) return false;
    if (assigneeFilter === 'mine' && t.assigneeId !== currentUser.id) return false;
    if (assigneeFilter !== 'all' && assigneeFilter !== 'mine' && t.assigneeId !== assigneeFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = t.title.toLowerCase().includes(q);
      const matchProject = t.project.toLowerCase().includes(q);
      const matchAssignee = t.assigneeName.toLowerCase().includes(q);
      return matchTitle || matchProject || matchAssignee;
    }
    return true;
  });

  // Mini Report Statistics Calculation
  const totalTasks = groupFilteredTasks.length;
  const completedTasks = groupFilteredTasks.filter(t => t.status === 'done').length;
  const inProgressTasks = groupFilteredTasks.filter(t => t.status === 'in_progress').length;
  const urgentTasks = groupFilteredTasks.filter(t => t.priority === 'urgent' && t.status !== 'done').length;
  const completionPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  // Checkpoints total & completed
  const allCheckpoints = groupFilteredTasks.flatMap(t => t.checkpoints || []);
  const totalCheckpoints = allCheckpoints.length;
  const completedCheckpoints = allCheckpoints.filter(cp => cp.isCompleted).length;
  const checkpointPercentage = totalCheckpoints > 0 ? Math.round((completedCheckpoints / totalCheckpoints) * 100) : 0;

  const columns: { id: TaskStatus; label: string; count: number; color: string }[] = [
    { id: 'backlog', label: 'Backlog', count: filteredTasks.filter(t => t.status === 'backlog').length, color: 'border-slate-300 dark:border-slate-700' },
    { id: 'todo', label: 'To Do', count: filteredTasks.filter(t => t.status === 'todo').length, color: 'border-slate-800 dark:border-slate-600' },
    { id: 'in_progress', label: 'In Progress', count: filteredTasks.filter(t => t.status === 'in_progress').length, color: 'border-blue-500' },
    { id: 'review', label: 'Review', count: filteredTasks.filter(t => t.status === 'review').length, color: 'border-amber-500' },
    { id: 'done', label: 'Done', count: filteredTasks.filter(t => t.status === 'done').length, color: 'border-emerald-500' }
  ];

  const handleDragStart = (e: React.DragEvent, id: string) => {
    e.dataTransfer.setData('text/plain', id);
    setDraggedTaskId(id);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetStatus: TaskStatus) => {
    e.preventDefault();
    const id = e.dataTransfer.getData('text/plain');
    if (id) {
      moveTaskStatus(id, targetStatus);
    }
    setDraggedTaskId(null);
  };

  const getPriorityBadge = (priority: TaskPriority) => {
    switch (priority) {
      case 'urgent':
        return { label: 'Urgent', bg: 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300' };
      case 'high':
        return { label: 'High', bg: 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300' };
      case 'medium':
        return { label: 'Medium', bg: 'bg-slate-200 text-slate-800 dark:bg-slate-800 dark:text-slate-200' };
      default:
        return { label: 'Low', bg: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400' };
    }
  };

  const handleAddCheckpointSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask || !newCheckpointTitle.trim()) return;
    addTaskCheckpoint(selectedTask.id, newCheckpointTitle, newCheckpointDate || undefined);
    setNewCheckpointTitle('');
    setNewCheckpointDate('');

    // Keep selectedTask state updated in modal
    const updated = tasks.find(t => t.id === selectedTask.id);
    if (updated) setSelectedTask(updated);
  };

  const handleAddReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask || !reportContent.trim()) return;
    addTaskReport(selectedTask.id, {
      type: reportType,
      content: reportContent
    });
    setReportContent('');

    // Keep selectedTask state updated in modal
    const updated = tasks.find(t => t.id === selectedTask.id);
    if (updated) setSelectedTask(updated);
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* 1. GROUP SWITCHER & ACCESS CONTROL BAR */}
      <div className="flex flex-col gap-3 rounded-3xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-slate-950 text-white dark:bg-slate-800 ring-1 ring-slate-800 shadow-xs">
            <Building2 className="h-5 w-5 text-red-500" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                Task Management Per Divisi
              </h2>
              {isSuperAdmin && (
                <span className="rounded-md bg-red-100 px-2 py-0.5 text-[10px] font-bold text-red-700 dark:bg-red-950/80 dark:text-red-300">
                  Universal Admin Access
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Setiap divisi memiliki board kerja terpisah. Akses dibatasi sesuai otorisasi tim.
            </p>
          </div>
        </div>

        {/* Group Selector Dropdown / Pills */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 hidden sm:inline">Pilih Board:</span>
          <select
            value={activeGroupId}
            onChange={e => setSelectedTaskGroup(e.target.value)}
            className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-bold text-slate-900 focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white shadow-2xs"
          >
            {isSuperAdmin && (
              <option value="all">🌐 Semua Divisi (Global Overview)</option>
            )}
            {TASK_GROUPS.map(g => (
              <option
                key={g.id}
                value={g.id}
                disabled={!isSuperAdmin && g.id !== userHomeGroup.id}
              >
                {g.name} {!isSuperAdmin && g.id !== userHomeGroup.id ? '🔒 (Terkunci)' : ''}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* ACCESS DENIED STATE FOR UNAUTHORIZED GROUPS */}
      {!hasAccessToCurrentGroup ? (
        <div className="rounded-3xl border border-red-200 bg-red-50/70 p-8 text-center dark:border-red-900/60 dark:bg-red-950/30">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-red-100 dark:bg-red-900/40 text-red-600 mb-3">
            <Lock className="h-7 w-7" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Akses Board Terbatas
          </h3>
          <p className="mt-1 text-xs text-slate-600 dark:text-slate-300 max-w-md mx-auto">
            Sesuai kebijakan keamanan perusahaan, Anda hanya diizinkan mengakses board divisi Anda (<strong>{currentUser.department}</strong>). Hanya <strong>Super Admin</strong> yang memiliki otorisasi penuh lintas divisi.
          </p>
          <button
            onClick={() => setSelectedTaskGroup(userHomeGroup.id)}
            className="mt-4 rounded-xl bg-slate-950 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-black transition"
          >
            Beralih ke Board Saya ({userHomeGroup.name})
          </button>
        </div>
      ) : (
        <>
          {/* 2. HEADER MINI STATISTIK & MINI REPORT (EXECUTIVE WIDGET) */}
          <div className="rounded-3xl border border-slate-200 bg-white p-4 sm:p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <FileBarChart className="h-4 w-4 text-red-600" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Mini Report & Statistik Capaian Tim: {activeGroupId === 'all' ? 'Semua Divisi' : TASK_GROUPS.find(g => g.id === activeGroupId)?.name}
                </h3>
              </div>
              <button
                onClick={() => setShowReportModal(true)}
                className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-bold text-slate-700 shadow-2xs hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 transition self-start sm:self-auto"
              >
                <FileText className="h-3.5 w-3.5 text-red-600" />
                <span>Lihat Laporan Lengkap Tim</span>
              </button>
            </div>

            {/* KPI Cards Grid */}
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-5">
              {/* Total Tasks */}
              <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-3 dark:border-slate-800 dark:bg-slate-800/40">
                <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">Total Tugas</div>
                <div className="mt-1 text-xl font-extrabold text-slate-900 dark:text-white">{totalTasks}</div>
                <div className="mt-1 text-[10px] text-slate-400">Aktif di board ini</div>
              </div>

              {/* Progress Rate */}
              <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-3 dark:border-slate-800 dark:bg-slate-800/40">
                <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">Selesai (Done)</div>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400">{completedTasks}</span>
                  <span className="text-xs font-bold text-slate-400">({completionPercentage}%)</span>
                </div>
                <div className="mt-1.5 h-1.5 w-full rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${completionPercentage}%` }} />
                </div>
              </div>

              {/* In Progress */}
              <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-3 dark:border-slate-800 dark:bg-slate-800/40">
                <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">Sedang Dikerjakan</div>
                <div className="mt-1 text-xl font-extrabold text-blue-600 dark:text-blue-400">{inProgressTasks}</div>
                <div className="mt-1 text-[10px] text-slate-400">Fokus pengerjaan aktif</div>
              </div>

              {/* Checkpoints Progress */}
              <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-3 dark:border-slate-800 dark:bg-slate-800/40">
                <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">Checkpoint Milestones</div>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className="text-xl font-extrabold text-slate-900 dark:text-white">{completedCheckpoints}/{totalCheckpoints}</span>
                  <span className="text-xs font-bold text-slate-400">({checkpointPercentage}%)</span>
                </div>
                <div className="mt-1.5 h-1.5 w-full rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                  <div className="h-full bg-slate-950 dark:bg-white rounded-full" style={{ width: `${checkpointPercentage}%` }} />
                </div>
              </div>

              {/* Urgent / Overdue */}
              <div className="rounded-2xl border border-red-100 bg-red-50/50 p-3 dark:border-red-950/60 dark:bg-red-950/20 col-span-2 sm:col-span-1">
                <div className="text-[10px] font-semibold text-red-600 dark:text-red-400">Prioritas Urgent</div>
                <div className="mt-1 text-xl font-extrabold text-red-600 dark:text-red-400">{urgentTasks}</div>
                <div className="mt-1 text-[10px] text-red-500/80">Perlu perhatian khusus</div>
              </div>
            </div>
          </div>

          {/* 3. ELONGATED SEARCH & TOOLBAR */}
          <div className="flex flex-col gap-3 rounded-3xl border border-slate-200 bg-white p-3.5 shadow-xs dark:border-slate-800 dark:bg-slate-900 md:flex-row md:items-center">
            {/* Elongated Search Bar - Stretches across the row */}
            <div className="relative flex-1 min-w-0">
              <Search className="absolute left-3.5 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Cari task berdasarkan judul, nomor tiket, checklist, atau anggota tim..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full rounded-2xl border border-slate-200 bg-slate-50/70 pl-10 pr-8 py-2 text-xs font-medium text-slate-800 placeholder-slate-400 focus:border-red-500 focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-100 dark:focus:bg-slate-800"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            {/* Inline Filters & View Switcher */}
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <select
                value={priorityFilter}
                onChange={e => setPriorityFilter(e.target.value)}
                className="rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs font-semibold text-slate-700 focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
              >
                <option value="all">Semua Prioritas</option>
                <option value="urgent">Urgent</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>

              <select
                value={assigneeFilter}
                onChange={e => setAssigneeFilter(e.target.value)}
                className="rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs font-semibold text-slate-700 focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
              >
                <option value="all">Semua Assignee</option>
                <option value="mine">Tugas Saya Saja</option>
                {users.map(u => (
                  <option key={u.id} value={u.id}>
                    {u.name}
                  </option>
                ))}
              </select>

              {/* View switcher buttons */}
              <div className="flex items-center gap-0.5 rounded-xl bg-slate-100 p-0.5 dark:bg-slate-800">
                <button
                  onClick={() => setViewMode('kanban')}
                  className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition ${
                    viewMode === 'kanban'
                      ? 'bg-slate-950 text-white shadow-2xs dark:bg-white dark:text-slate-900'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                  title="Kanban Board"
                >
                  <Kanban className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Kanban</span>
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition ${
                    viewMode === 'list'
                      ? 'bg-slate-950 text-white shadow-2xs dark:bg-white dark:text-slate-900'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                  title="Tabel List"
                >
                  <List className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">List</span>
                </button>
                <button
                  onClick={() => setViewMode('calendar')}
                  className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition ${
                    viewMode === 'calendar'
                      ? 'bg-slate-950 text-white shadow-2xs dark:bg-white dark:text-slate-900'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                  title="Timeline Jadwal"
                >
                  <CalendarIcon className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Timeline</span>
                </button>
              </div>

              {/* New Task button (Navy primary with subtle red highlight) */}
              <button
                onClick={() => setQuickActionModal('task')}
                className="flex items-center gap-1.5 rounded-xl bg-slate-950 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-black active:scale-95 shrink-0 border border-slate-800"
              >
                <Plus className="h-3.5 w-3.5 text-red-500" />
                <span>Task Baru</span>
              </button>
            </div>
          </div>

          {/* 4. VIEW: KANBAN BOARD */}
          {viewMode === 'kanban' && (
            <div className="grid grid-cols-1 gap-4 overflow-x-auto pb-4 md:grid-cols-3 lg:grid-cols-5 min-w-[950px]">
              {columns.map(col => {
                const colTasks = filteredTasks.filter(t => t.status === col.id);
                return (
                  <div
                    key={col.id}
                    onDragOver={handleDragOver}
                    onDrop={e => handleDrop(e, col.id)}
                    className="flex flex-col rounded-3xl border border-slate-200 bg-slate-50/60 p-3 dark:border-slate-800/80 dark:bg-slate-900/50 min-h-[500px]"
                  >
                    {/* Column Header */}
                    <div className={`flex items-center justify-between border-t-4 ${col.color} pt-2 pb-3 px-1`}>
                      <span className="text-xs font-bold text-slate-900 dark:text-white">
                        {col.label}
                      </span>
                      <span className="rounded-full bg-slate-200 px-2 py-0.5 text-[10px] font-bold text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                        {col.count}
                      </span>
                    </div>

                    {/* Task Cards List */}
                    <div className="flex-1 space-y-2.5 overflow-y-auto">
                      {colTasks.length === 0 ? (
                        <div className="flex h-32 items-center justify-center rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 p-4 text-center text-slate-400">
                          <p className="text-[11px]">Tarik task ke sini</p>
                        </div>
                      ) : (
                        colTasks.map(task => {
                          const priority = getPriorityBadge(task.priority);
                          const totalCp = (task.checkpoints || []).length;
                          const doneCp = (task.checkpoints || []).filter(c => c.isCompleted).length;
                          const totalReports = (task.reports || []).length;

                          return (
                            <div
                              key={task.id}
                              draggable
                              onDragStart={e => handleDragStart(e, task.id)}
                              onClick={() => setSelectedTask(task)}
                              className="group relative cursor-pointer rounded-2xl border border-slate-200 bg-white p-3.5 shadow-xs transition hover:border-slate-400 hover:shadow-md dark:border-slate-800 dark:bg-slate-800/90"
                            >
                              {/* Labels & Priority */}
                              <div className="flex items-center justify-between gap-1 mb-2">
                                <span className={`rounded-md px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider ${priority.bg}`}>
                                  {priority.label}
                                </span>
                                <span className="text-[10px] font-medium text-slate-400 truncate max-w-[120px]">
                                  {task.project}
                                </span>
                              </div>

                              {/* Task Title */}
                              <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-2 leading-relaxed">
                                {task.title}
                              </h4>

                              {/* Checkpoints / Milestone Indicator if present */}
                              {totalCp > 0 && (
                                <div className="mt-2.5 rounded-xl bg-slate-50 p-2 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800">
                                  <div className="flex items-center justify-between text-[10px] font-bold text-slate-700 dark:text-slate-300">
                                    <span className="flex items-center gap-1">
                                      <Flag className="h-3 w-3 text-red-500" />
                                      <span>Milestones</span>
                                    </span>
                                    <span>{doneCp}/{totalCp}</span>
                                  </div>
                                  <div className="mt-1 h-1 w-full rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                                    <div
                                      className="h-full bg-slate-950 dark:bg-white rounded-full transition-all"
                                      style={{ width: `${(doneCp / totalCp) * 100}%` }}
                                    />
                                  </div>
                                </div>
                              )}

                              {/* Footer: Assignee & Meta badges */}
                              <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2.5 dark:border-slate-700/60 text-[10px] text-slate-400">
                                <div className="flex items-center gap-1.5">
                                  <img
                                    src={task.assigneeAvatar}
                                    alt={task.assigneeName}
                                    className="h-5 w-5 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                                  />
                                  <span className="truncate max-w-[80px] font-medium text-slate-600 dark:text-slate-300">
                                    {task.assigneeName.split(' ')[0]}
                                  </span>
                                </div>

                                <div className="flex items-center gap-2">
                                  {totalReports > 0 && (
                                    <span className="flex items-center gap-0.5 text-blue-600 dark:text-blue-400 font-semibold" title="Laporan & Catatan">
                                      <FileText className="h-3 w-3" />
                                      <span>{totalReports}</span>
                                    </span>
                                  )}
                                  <span className="flex items-center gap-0.5">
                                    <Clock className="h-3 w-3" />
                                    <span>{task.deadline.substring(5)}</span>
                                  </span>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* 5. VIEW: TABLE LIST VIEW */}
          {viewMode === 'list' && (
            <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-xs dark:border-slate-800 dark:bg-slate-900">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-200 bg-slate-50/80 font-bold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-800/80">
                    <tr>
                      <th className="px-4 py-3">Judul Task</th>
                      <th className="px-4 py-3">Proyek & Divisi</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Prioritas</th>
                      <th className="px-4 py-3">Milestone Checkpoints</th>
                      <th className="px-4 py-3">Assignee</th>
                      <th className="px-4 py-3">Deadline</th>
                      <th className="px-4 py-3 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredTasks.map(t => {
                      const priority = getPriorityBadge(t.priority);
                      const totalCp = (t.checkpoints || []).length;
                      const doneCp = (t.checkpoints || []).filter(c => c.isCompleted).length;

                      return (
                        <tr
                          key={t.id}
                          className="transition hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer"
                          onClick={() => setSelectedTask(t)}
                        >
                          <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                            <div className="flex items-center gap-2">
                              <CheckCircle2
                                onClick={e => {
                                  e.stopPropagation();
                                  moveTaskStatus(t.id, t.status === 'done' ? 'in_progress' : 'done');
                                }}
                                className={`h-4 w-4 cursor-pointer transition ${
                                  t.status === 'done' ? 'text-emerald-500' : 'text-slate-300 hover:text-emerald-500'
                                }`}
                              />
                              <span className={t.status === 'done' ? 'line-through text-slate-400' : ''}>
                                {t.title}
                              </span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-slate-500">
                            <div>{t.project}</div>
                            <div className="text-[10px] text-slate-400">{t.groupName || t.assigneeDept}</div>
                          </td>
                          <td className="px-4 py-3">
                            <select
                              value={t.status}
                              onClick={e => e.stopPropagation()}
                              onChange={e => moveTaskStatus(t.id, e.target.value as TaskStatus)}
                              className="rounded-lg bg-slate-100 px-2 py-1 text-[11px] font-bold text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                            >
                              <option value="backlog">Backlog</option>
                              <option value="todo">To Do</option>
                              <option value="in_progress">In Progress</option>
                              <option value="review">Review</option>
                              <option value="done">Done</option>
                            </select>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase ${priority.bg}`}>
                              {priority.label}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            {totalCp > 0 ? (
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-slate-700 dark:text-slate-300">{doneCp}/{totalCp}</span>
                                <div className="h-1.5 w-16 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                                  <div className="h-full bg-slate-950 dark:bg-white" style={{ width: `${(doneCp / totalCp) * 100}%` }} />
                                </div>
                              </div>
                            ) : (
                              <span className="text-slate-400 text-[11px]">-</span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <img src={t.assigneeAvatar} alt="" className="h-6 w-6 rounded-full object-cover" />
                              <span>{t.assigneeName}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 font-mono text-[11px] text-slate-500">{t.deadline}</td>
                          <td className="px-4 py-3 text-right">
                            <button
                              onClick={e => {
                                e.stopPropagation();
                                deleteTask(t.id);
                              }}
                              className="rounded-lg p-1.5 text-slate-400 hover:text-red-600"
                              title="Hapus Task"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 6. VIEW: CALENDAR TIMELINE VIEW */}
          {viewMode === 'calendar' && (
            <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-xs dark:border-slate-800 dark:bg-slate-900">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Timeline Tenggat Waktu Bulan Ini
                </h3>
                <span className="text-xs text-slate-500">Tampilan Terpadu Deadlines</span>
              </div>

              <div className="space-y-3">
                {filteredTasks
                  .sort((a, b) => a.deadline.localeCompare(b.deadline))
                  .map(t => (
                    <div
                      key={t.id}
                      onClick={() => setSelectedTask(t)}
                      className="flex cursor-pointer items-center justify-between rounded-2xl border border-slate-100 bg-slate-50/70 p-3.5 transition hover:border-slate-300 dark:border-slate-800 dark:bg-slate-800/40"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex flex-col items-center justify-center rounded-xl bg-slate-950 px-3 py-1.5 font-mono text-xs font-bold text-white">
                          <span>{t.deadline.substring(8)}</span>
                          <span className="text-[9px] uppercase text-red-400">NOV</span>
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                            {t.title}
                          </h4>
                          <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-500">
                            <span>{t.project}</span>
                            <span>•</span>
                            <span>Assignee: {t.assigneeName}</span>
                            {(t.checkpoints || []).length > 0 && (
                              <>
                                <span>•</span>
                                <span className="text-red-600 dark:text-red-400 font-semibold">
                                  🚩 {(t.checkpoints || []).filter(c => c.isCompleted).length}/{(t.checkpoints || []).length} Milestones
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      <span
                        className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase ${
                          t.status === 'done'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {t.status}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* 7. TASK DETAILS MODAL WITH CHECKPOINT TRACKER & REPORT/CHAT STREAM */}
      {selectedTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-2xl rounded-3xl bg-white p-6 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-slate-100 pb-4 dark:border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-red-600 uppercase tracking-wider">
                    {selectedTask.project}
                  </span>
                  <span className="text-slate-300 dark:text-slate-700">•</span>
                  <span className="text-[11px] text-slate-500 font-semibold">
                    Divisi: {selectedTask.groupName || selectedTask.assigneeDept}
                  </span>
                </div>
                <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mt-1">
                  {selectedTask.title}
                </h2>
              </div>
              <button
                onClick={() => setSelectedTask(null)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 space-y-5">
              {/* Status and priority controls */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-2xl dark:bg-slate-800/60 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">Status</span>
                  <select
                    value={selectedTask.status}
                    onChange={e => {
                      moveTaskStatus(selectedTask.id, e.target.value as TaskStatus);
                      setSelectedTask({ ...selectedTask, status: e.target.value as TaskStatus });
                    }}
                    className="mt-1 font-bold text-slate-800 dark:text-slate-200 bg-transparent focus:outline-none"
                  >
                    <option value="backlog">Backlog</option>
                    <option value="todo">To Do</option>
                    <option value="in_progress">In Progress</option>
                    <option value="review">Review</option>
                    <option value="done">Done</option>
                  </select>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">Prioritas</span>
                  <span className="font-bold text-red-600 uppercase">{selectedTask.priority}</span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">Deadline</span>
                  <span className="font-mono text-slate-700 dark:text-slate-300">{selectedTask.deadline}</span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">Assignee</span>
                  <div className="flex items-center gap-1.5 mt-1 font-bold">
                    <img src={selectedTask.assigneeAvatar} alt="" className="h-4 w-4 rounded-full object-cover" />
                    <span className="truncate">{selectedTask.assigneeName.split(' ')[0]}</span>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Deskripsi Pekerjaan
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50/50 p-3 rounded-xl border border-slate-100 dark:bg-slate-800/40 dark:border-slate-800">
                  {selectedTask.description}
                </p>
              </div>

              {/* FITUR CHECKPOINT / PROJECT MILESTONES */}
              <div className="rounded-2xl border border-slate-200 bg-slate-50/50 p-4 dark:border-slate-800 dark:bg-slate-850">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Flag className="h-4 w-4 text-red-600" />
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      Tracking Checkpoint & Milestones Proyek
                    </h4>
                  </div>
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    {(selectedTask.checkpoints || []).filter(c => c.isCompleted).length} / {(selectedTask.checkpoints || []).length} Selesai
                  </span>
                </div>

                {/* Progress bar */}
                <div className="h-2 w-full rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden mb-3">
                  <div
                    className="h-full bg-slate-950 dark:bg-white rounded-full transition-all duration-300"
                    style={{
                      width: `${(selectedTask.checkpoints || []).length > 0
                        ? (((selectedTask.checkpoints || []).filter(c => c.isCompleted).length / (selectedTask.checkpoints || []).length) * 100)
                        : 0}%`
                    }}
                  />
                </div>

                {/* Checkpoint list */}
                <div className="space-y-2 mb-3">
                  {(selectedTask.checkpoints || []).map(cp => (
                    <div
                      key={cp.id}
                      onClick={() => {
                        toggleTaskCheckpoint(selectedTask.id, cp.id);
                        const updatedCheckpoints = (selectedTask.checkpoints || []).map(c =>
                          c.id === cp.id ? { ...c, isCompleted: !c.isCompleted } : c
                        );
                        setSelectedTask({ ...selectedTask, checkpoints: updatedCheckpoints });
                      }}
                      className={`flex cursor-pointer items-center justify-between rounded-xl border p-2.5 text-xs transition ${
                        cp.isCompleted
                          ? 'border-emerald-200 bg-emerald-50/50 text-slate-800 dark:border-emerald-900/50 dark:bg-emerald-950/20 dark:text-slate-200'
                          : 'border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <input
                          type="checkbox"
                          checked={cp.isCompleted}
                          onChange={() => {}}
                          className="rounded text-red-600"
                        />
                        <span className={cp.isCompleted ? 'line-through text-slate-400 font-medium' : 'font-bold'}>
                          {cp.title}
                        </span>
                      </div>
                      {cp.targetDate && (
                        <span className="text-[10px] text-slate-400 font-mono">
                          Target: {cp.targetDate}
                        </span>
                      )}
                    </div>
                  ))}
                </div>

                {/* Add new checkpoint inline form */}
                <form onSubmit={handleAddCheckpointSubmit} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Tambah checkpoint baru (cth: UAT Client Signed)..."
                    value={newCheckpointTitle}
                    onChange={e => setNewCheckpointTitle(e.target.value)}
                    className="flex-1 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
                  />
                  <input
                    type="date"
                    value={newCheckpointDate}
                    onChange={e => setNewCheckpointDate(e.target.value)}
                    className="rounded-xl border border-slate-200 bg-white px-2 py-1.5 text-xs focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
                  />
                  <button
                    type="submit"
                    disabled={!newCheckpointTitle.trim()}
                    className="rounded-xl bg-slate-950 px-3 py-1.5 text-xs font-bold text-white hover:bg-black disabled:opacity-50"
                  >
                    + Tambah
                  </button>
                </form>
              </div>

              {/* FITUR REPORT DENGAN CHAT & NOTES (DISCUSSION STREAM) */}
              <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-850">
                <div className="flex items-center gap-2 mb-3">
                  <FileText className="h-4 w-4 text-red-600" />
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    Laporan Progres, Catatan & Kendala Blocker
                  </h4>
                </div>

                {/* Form to submit new report */}
                <form onSubmit={handleAddReportSubmit} className="space-y-2 mb-4 bg-slate-50 p-3 rounded-2xl dark:bg-slate-800/60">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">Tipe Laporan:</span>
                    <button
                      type="button"
                      onClick={() => setReportType('progress_update')}
                      className={`rounded-lg px-2 py-1 font-bold text-[11px] transition ${
                        reportType === 'progress_update'
                          ? 'bg-slate-950 text-white dark:bg-white dark:text-slate-900'
                          : 'bg-white text-slate-600 dark:bg-slate-700 dark:text-slate-300'
                      }`}
                    >
                      🚀 Progres
                    </button>
                    <button
                      type="button"
                      onClick={() => setReportType('blocker')}
                      className={`rounded-lg px-2 py-1 font-bold text-[11px] transition ${
                        reportType === 'blocker'
                          ? 'bg-red-600 text-white'
                          : 'bg-white text-slate-600 dark:bg-slate-700 dark:text-slate-300'
                      }`}
                    >
                      ⚠️ Blocker
                    </button>
                    <button
                      type="button"
                      onClick={() => setReportType('note')}
                      className={`rounded-lg px-2 py-1 font-bold text-[11px] transition ${
                        reportType === 'note'
                          ? 'bg-blue-600 text-white'
                          : 'bg-white text-slate-600 dark:bg-slate-700 dark:text-slate-300'
                      }`}
                    >
                      📝 Catatan
                    </button>
                  </div>

                  <div className="flex gap-2">
                    <textarea
                      placeholder="Tulis update progres milestone, status penanganan kendala, atau catatan kerja..."
                      value={reportContent}
                      onChange={e => setReportContent(e.target.value)}
                      rows={2}
                      className="flex-1 rounded-xl border border-slate-200 bg-white p-2.5 text-xs text-slate-800 placeholder-slate-400 focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 resize-none"
                    />
                    <button
                      type="submit"
                      disabled={!reportContent.trim()}
                      className="self-end rounded-xl bg-slate-950 p-2.5 text-white hover:bg-black disabled:opacity-40"
                      title="Kirim Laporan"
                    >
                      <Send className="h-4 w-4" />
                    </button>
                  </div>
                </form>

                {/* Reports Feed */}
                <div className="space-y-2.5 max-h-56 overflow-y-auto">
                  {(selectedTask.reports || []).length === 0 ? (
                    <p className="text-center text-xs text-slate-400 py-4">
                      Belum ada laporan atau catatan progres untuk task ini.
                    </p>
                  ) : (
                    (selectedTask.reports || []).map(rep => (
                      <div
                        key={rep.id}
                        className={`rounded-xl p-3 text-xs border ${
                          rep.type === 'blocker'
                            ? 'border-red-200 bg-red-50/60 dark:border-red-900/40 dark:bg-red-950/20'
                            : rep.type === 'progress_update'
                            ? 'border-emerald-200 bg-emerald-50/40 dark:border-emerald-900/40 dark:bg-emerald-950/20'
                            : 'border-slate-200 bg-slate-50/50 dark:border-slate-800 dark:bg-slate-800/40'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-1.5">
                            <img src={rep.authorAvatar} alt="" className="h-4 w-4 rounded-full object-cover" />
                            <span className="font-bold text-slate-900 dark:text-white">{rep.authorName}</span>
                            <span
                              className={`rounded px-1.5 py-0.2 text-[9px] font-extrabold uppercase ${
                                rep.type === 'blocker'
                                  ? 'bg-red-600 text-white'
                                  : rep.type === 'progress_update'
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-blue-600 text-white'
                              }`}
                            >
                              {rep.type === 'blocker' ? 'BLOCKER' : rep.type === 'progress_update' ? 'PROGRES' : 'CATATAN'}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400">
                            {new Date(rep.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap pl-5">
                          {rep.content}
                        </p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
              <button
                onClick={() => setSelectedTask(null)}
                className="rounded-xl bg-slate-950 px-5 py-2 text-xs font-bold text-white hover:bg-black transition"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. MINI REPORT MODAL (RINGKASAN EKSEKUTIF CAPAIAN TIM) */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-xl rounded-3xl bg-white p-6 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <FileBarChart className="h-5 w-5 text-red-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Laporan Ringkas Kinerja & Milestones Tim
                </h3>
              </div>
              <button
                onClick={() => setShowReportModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs">
              <div className="rounded-2xl bg-slate-50 p-4 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                <div className="font-bold text-slate-800 dark:text-slate-200">
                  Divisi: {activeGroupId === 'all' ? 'Seluruh Divisi Perusahaan' : TASK_GROUPS.find(g => g.id === activeGroupId)?.name}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  Periode Sprint: Q4 2026 • Dihasilkan otomatis oleh WORKSPACE Operating System
                </div>
              </div>

              {/* Metrics Breakdown */}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-xl border border-slate-200 p-2.5 dark:border-slate-700">
                  <div className="text-[10px] text-slate-400">Total Deliverables</div>
                  <div className="text-base font-extrabold text-slate-900 dark:text-white mt-1">{totalTasks} Task</div>
                </div>
                <div className="rounded-xl border border-slate-200 p-2.5 dark:border-slate-700">
                  <div className="text-[10px] text-slate-400">Tingkat Penyelesaian</div>
                  <div className="text-base font-extrabold text-emerald-600 mt-1">{completionPercentage}%</div>
                </div>
                <div className="rounded-xl border border-slate-200 p-2.5 dark:border-slate-700">
                  <div className="text-[10px] text-slate-400">Milestone Checkpoint</div>
                  <div className="text-base font-extrabold text-slate-900 dark:text-white mt-1">{completedCheckpoints}/{totalCheckpoints}</div>
                </div>
              </div>

              {/* Status List */}
              <div className="space-y-2">
                <div className="font-bold text-slate-700 dark:text-slate-300">
                  Ringkasan Task Kunci:
                </div>
                {groupFilteredTasks.slice(0, 5).map(t => (
                  <div key={t.id} className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-[11px]">
                    <span className="font-medium truncate max-w-[280px] text-slate-800 dark:text-slate-200">{t.title}</span>
                    <span className="font-bold text-slate-600 dark:text-slate-400 uppercase">{t.status}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-5 flex justify-end gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
              <button
                onClick={() => {
                  window.print();
                }}
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <Printer className="h-3.5 w-3.5" />
                <span>Cetak Ringkasan</span>
              </button>
              <button
                onClick={() => setShowReportModal(false)}
                className="rounded-xl bg-slate-950 px-4 py-1.5 text-xs font-bold text-white hover:bg-black"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
