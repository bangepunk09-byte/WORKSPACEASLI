import React, { useState } from 'react';
import { X, CheckSquare, Plus } from 'lucide-react';
import { useWorkspace } from '../../context/WorkspaceContext';
import { TaskPriority, TaskStatus } from '../../types';

export const CreateTaskModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { currentUser, users, createTask } = useWorkspace();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [project, setProject] = useState('Core Infrastructure & Security');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [status, setStatus] = useState<TaskStatus>('todo');
  const [assigneeId, setAssigneeId] = useState(currentUser.id);
  const [deadline, setDeadline] = useState('2026-11-06');
  const [labelsInput, setLabelsInput] = useState('Frontend, Urgent, Release');
  const [checklists, setChecklists] = useState(['Analisa requirement awal', 'Implementasi dan testing']);

  const handleAddChecklist = () => {
    setChecklists([...checklists, '']);
  };

  const handleChecklistChange = (idx: number, val: string) => {
    const updated = [...checklists];
    updated[idx] = val;
    setChecklists(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const assignee = users.find(u => u.id === assigneeId) || currentUser;

    createTask({
      title,
      description,
      project,
      status,
      priority,
      assigneeId: assignee.id,
      assigneeName: assignee.name,
      assigneeAvatar: assignee.avatar,
      assigneeDept: assignee.department,
      reporterId: currentUser.id,
      reporterName: currentUser.name,
      deadline,
      labels: labelsInput.split(',').map(l => l.trim()).filter(Boolean),
      checklists: checklists
        .filter(c => c.trim().length > 0)
        .map((text, idx) => ({
          id: 'chk_' + Date.now() + '_' + idx,
          text,
          completed: false
        }))
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <CheckSquare className="h-5 w-5 text-red-600" />
            Buat Tugas (Task) Baru
          </h3>
          <button onClick={onClose} className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
          <div>
            <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
              Judul Tugas *
            </label>
            <input
              type="text"
              placeholder="contoh: Integrasi API Payment Gateway & Review Security"
              value={title}
              onChange={e => setTitle(e.target.value)}
              required
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Workspace / Proyek
              </label>
              <input
                type="text"
                value={project}
                onChange={e => setProject(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Tenggat Waktu (Deadline)
              </label>
              <input
                type="date"
                value={deadline}
                onChange={e => setDeadline(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Assignee
              </label>
              <select
                value={assigneeId}
                onChange={e => setAssigneeId(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
              >
                {users.map(u => (
                  <option key={u.id} value={u.id}>
                    {u.name.split(' ')[0]} ({u.role})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Prioritas
              </label>
              <select
                value={priority}
                onChange={e => setPriority(e.target.value as TaskPriority)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
              >
                <option value="urgent">Urgent</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Kolom Status
              </label>
              <select
                value={status}
                onChange={e => setStatus(e.target.value as TaskStatus)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
              >
                <option value="backlog">Backlog</option>
                <option value="todo">To Do</option>
                <option value="in_progress">In Progress</option>
                <option value="review">Review</option>
                <option value="done">Done</option>
              </select>
            </div>
          </div>

          <div>
            <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
              Deskripsi Singkat
            </label>
            <textarea
              placeholder="Rincian scope pekerjaan dan ekspektasi hasil..."
              value={description}
              onChange={e => setDescription(e.target.value)}
              rows={2}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
            />
          </div>

          {/* Subtask Checklists */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-bold text-slate-700 dark:text-slate-300">
                Daftar Checklist / Subtasks
              </label>
              <button
                type="button"
                onClick={handleAddChecklist}
                className="text-[11px] font-bold text-red-600 hover:underline"
              >
                + Tambah Item
              </button>
            </div>
            <div className="space-y-1.5">
              {checklists.map((c, i) => (
                <input
                  key={i}
                  type="text"
                  placeholder={`Subtask ${i + 1}`}
                  value={c}
                  onChange={e => handleChecklistChange(i, e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs focus:border-red-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
                />
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300"
            >
              Batal
            </button>
            <button
              type="submit"
              className="rounded-xl bg-red-600 px-5 py-2 text-xs font-bold text-white hover:bg-red-700 shadow-sm"
            >
              Simpan Tugas
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
